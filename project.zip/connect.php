<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'projectdb';
$conn=new mysqli($servername ,$username ,$password ,$dbname );
$conn->set_charset('utf8');

?>