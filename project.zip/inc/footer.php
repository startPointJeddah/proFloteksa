
		<footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" role="contentinfo">
			<div class='footer-width-fixer'>		<div data-elementor-type="wp-post" data-elementor-id="86" class="elementor elementor-86">
									<section class="elementor-section elementor-top-section elementor-element elementor-element-805ad6c elementor-section-boxed elementor-section-height-default elementor-section-height-default" data-id="805ad6c" data-element_type="section">
						<div class="elementor-container elementor-column-gap-default">
					<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-7df0707" data-id="7df0707" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
			
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-d8f174b" data-id="d8f174b" data-element_type="column">
			<div class="elementor-widget-wrap elementor-element-populated">
								<div class="elementor-element elementor-element-c33c4bc elementor-widget elementor-widget-heading" data-id="c33c4bc" data-element_type="widget" data-widget_type="heading.default">
				<div class="elementor-widget-container">
			<h5 class="elementor-heading-title elementor-size-default">
        جميع الحقوق محفوظة <?php echo date(Y); ?>
 </h5>		</div>
				</div>
					</div>
		</div>
				<div class="elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-a843710" data-id="a843710" data-element_type="column">
			<div class="elementor-widget-wrap">
									</div>
		</div>
							</div>
		</section>
							</div>
		</div>		</footer>
		</div><!-- #page -->
<script id='astra-theme-js-js-extra'>
var astra = {"break_point":"921","isRtl":"1"};
</script>
<script src='https://project.floteksa.com/wp-content/themes/astra/assets/js/minified/frontend.min.js?ver=3.9.1' id='astra-theme-js-js'></script>
<script src='https://project.floteksa.com/wp-content/plugins/elementskit-lite/libs/framework/assets/js/frontend-script.js?ver=2.7.0' id='elementskit-framework-js-frontend-js'></script>
<script id='elementskit-framework-js-frontend-js-after'>
		var elementskit = {
			resturl: 'https://project.floteksa.com/wp-json/elementskit/v1/',
		}

		
</script>
<script src='https://project.floteksa.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/widget-scripts.js?ver=2.7.0' id='ekit-widget-scripts-js'></script>
<script id='site-reviews-js-before'>
window.hasOwnProperty("GLSR")||(window.GLSR={});GLSR.action="glsr_action";GLSR.ajaxpagination=["#wpadminbar",".site-navigation-fixed"];GLSR.ajaxurl="insert-reviews.php";GLSR.captcha=[];GLSR.nameprefix="site-reviews";GLSR.stars={"clearable":false,"tooltip":false};GLSR.state={"popstate":false};GLSR.urlparameter=true;GLSR.validationconfig={field:"glsr-field",form:"glsr-form","field_error":"glsr-field-is-invalid","field_message":"glsr-field-error","field_required":"glsr-required","field_valid":"glsr-field-is-valid","form_error":"glsr-form-is-invalid","form_message":"glsr-form-message","form_message_failed":"glsr-form-failed","form_message_success":"glsr-form-success","input_error":"glsr-is-invalid","input_valid":"glsr-is-valid"};GLSR.validationstrings={accepted:"This field must be accepted.",between:"This field value must be between %s and %s.",betweenlength:"This field must have between %s and %s characters.",email:"This field requires a valid e-mail address.",errors:"خطأ ، افحص الاخطاء واعد المحاولة.",max:"Maximum value for this field is %s.",maxlength:"This field allows a maximum of %s characters.",min:"Minimum value for this field is %s.",minlength:"This field requires a minimum of %s characters.",number:"This field requires a number.",pattern:"Please match the requested format.",regex:"Please match the requested format.",required:"هذا الحقل مطلوب .",tel:"This field requires a valid telephone number.",url:"This field requires a valid website URL (make sure it starts with http or https).",unsupported:"The review could not be submitted because this browser is too old. Please try again with a modern browser."};GLSR.version="5.25.1";
</script>
<script src='https://project.floteksa.com/wp-content/plugins/site-reviews/assets/scripts/site-reviews.js?ver=5.25.1' id='site-reviews-js'></script>
<script id='site-reviews-js-after'>
function glsr_init_elementor(){GLSR.Event.trigger("site-reviews/init")}"undefined"!==typeof jQuery&&(jQuery(document).on("elementor/popup/show",glsr_init_elementor),jQuery(window).on("elementor/frontend/init",function(){elementorFrontend.hooks.addAction("frontend/element_ready/site_reviews.default",glsr_init_elementor);elementorFrontend.hooks.addAction("frontend/element_ready/site_reviews_form.default",glsr_init_elementor)}));
</script>
<script src='https://project.floteksa.com/wp-content/plugins/elementor-pro/assets/js/webpack-pro.runtime.min.js?ver=3.7.3' id='elementor-pro-webpack-runtime-js'></script>
<script src='https://project.floteksa.com/wp-content/plugins/elementor/assets/js/webpack.runtime.min.js?ver=3.7.4' id='elementor-webpack-runtime-js'></script>
<script src='https://project.floteksa.com/wp-content/plugins/elementor/assets/js/frontend-modules.min.js?ver=3.7.4' id='elementor-frontend-modules-js'></script>
<script src='https://project.floteksa.com/wp-includes/js/dist/vendor/regenerator-runtime.min.js?ver=0.13.9' id='regenerator-runtime-js'></script>
<script src='https://project.floteksa.com/wp-includes/js/dist/vendor/wp-polyfill.min.js?ver=3.15.0' id='wp-polyfill-js'></script>
<script src='https://project.floteksa.com/wp-includes/js/dist/hooks.min.js?ver=c6d64f2cb8f5c6bb49caca37f8828ce3' id='wp-hooks-js'></script>
<script src='https://project.floteksa.com/wp-includes/js/dist/i18n.min.js?ver=ebee46757c6a411e38fd079a7ac71d94' id='wp-i18n-js'></script>
<script id='wp-i18n-js-after'>
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'rtl' ] } );
</script>
<script id='elementor-pro-frontend-js-before'>
var ElementorProFrontendConfig = {"ajaxurl":"https:\/\/project.floteksa.com\/wp-admin\/admin-ajax.php","nonce":"cd756e04b2","urls":{"assets":"https:\/\/project.floteksa.com\/wp-content\/plugins\/elementor-pro\/assets\/","rest":"https:\/\/project.floteksa.com\/wp-json\/"},"shareButtonsNetworks":{"facebook":{"title":"Facebook","has_counter":true},"twitter":{"title":"Twitter"},"linkedin":{"title":"LinkedIn","has_counter":true},"pinterest":{"title":"Pinterest","has_counter":true},"reddit":{"title":"Reddit","has_counter":true},"vk":{"title":"VK","has_counter":true},"odnoklassniki":{"title":"OK","has_counter":true},"tumblr":{"title":"Tumblr"},"digg":{"title":"Digg"},"skype":{"title":"Skype"},"stumbleupon":{"title":"StumbleUpon","has_counter":true},"mix":{"title":"Mix"},"telegram":{"title":"Telegram"},"pocket":{"title":"Pocket","has_counter":true},"xing":{"title":"XING","has_counter":true},"whatsapp":{"title":"WhatsApp"},"email":{"title":"Email"},"print":{"title":"Print"}},"facebook_sdk":{"lang":"ar","app_id":""},"lottie":{"defaultAnimationUrl":"https:\/\/project.floteksa.com\/wp-content\/plugins\/elementor-pro\/modules\/lottie\/assets\/animations\/default.json"}};
</script>
<script src='https://project.floteksa.com/wp-content/plugins/elementor-pro/assets/js/frontend.min.js?ver=3.7.3' id='elementor-pro-frontend-js'></script>
<script src='https://project.floteksa.com/wp-content/plugins/elementor/assets/lib/waypoints/waypoints.min.js?ver=4.0.2' id='elementor-waypoints-js'></script>
<script src='https://project.floteksa.com/wp-includes/js/jquery/ui/core.min.js?ver=1.13.1' id='jquery-ui-core-js'></script>
<script id='elementor-frontend-js-before'>
var elementorFrontendConfig = {"environmentMode":{"edit":false,"wpPreview":false,"isScriptDebug":false},"i18n":{"shareOnFacebook":"\u0634\u0627\u0631\u0643 \u0639\u0644\u0649 \u0641\u064a\u0633\u0628\u0648\u0643","shareOnTwitter":"\u0634\u0627\u0631\u0643 \u0639\u0644\u0649 \u062a\u0648\u064a\u062a\u0631","pinIt":"\u062b\u0628\u062a\u0647\u0627 ","download":"\u062a\u062d\u0645\u064a\u0644","downloadImage":"\u062a\u0646\u0632\u064a\u0644 \u0627\u0644\u0635\u0648\u0631\u0629","fullscreen":"\u0639\u0631\u0636 \u0634\u0627\u0634\u0629 \u0643\u0627\u0645\u0644\u0629","zoom":"\u062a\u0643\u0628\u064a\u0631","share":"\u0645\u0634\u0627\u0631\u0643\u0629","playVideo":"\u062a\u0634\u063a\u064a\u0644 \u0627\u0644\u0641\u064a\u062f\u064a\u0648","previous":"\u0627\u0644\u0633\u0627\u0628\u0642","next":"\u0627\u0644\u062a\u0627\u0644\u064a","close":"\u0625\u063a\u0644\u0627\u0642"},"is_rtl":true,"breakpoints":{"xs":0,"sm":480,"md":768,"lg":1025,"xl":1440,"xxl":1600},"responsive":{"breakpoints":{"mobile":{"label":"\u0627\u0644\u0647\u0627\u062a\u0641 \u0627\u0644\u0645\u062d\u0645\u0648\u0644","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"\u0647\u0627\u062a\u0641 \u0645\u062d\u0645\u0648\u0644 - \u0623\u0641\u0642\u064a","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"\u0627\u0644\u0623\u062c\u0647\u0632\u0629 \u0627\u0644\u0644\u0648\u062d\u064a\u0629","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"\u062c\u0647\u0627\u0632 \u0644\u0648\u062d\u064a -\u0623\u0641\u0642\u064a","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"\u062d\u0627\u0633\u0648\u0628 \u0645\u062d\u0645\u0648\u0644","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"\u0627\u0644\u0634\u0627\u0634\u0629 \u0627\u0644\u0639\u0631\u064a\u0636\u0629","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}},"version":"3.7.4","is_static":false,"experimentalFeatures":{"e_dom_optimization":true,"e_optimized_assets_loading":true,"e_optimized_css_loading":true,"a11y_improvements":true,"additional_custom_breakpoints":true,"e_import_export":true,"e_hidden_wordpress_widgets":true,"theme_builder_v2":true,"landing-pages":true,"elements-color-picker":true,"favorite-widgets":true,"admin-top-bar":true,"page-transitions":true,"notes":true,"form-submissions":true,"e_scroll_snap":true},"urls":{"assets":"https:\/\/project.floteksa.com\/wp-content\/plugins\/elementor\/assets\/"},"settings":{"page":[],"editorPreferences":[]},"kit":{"active_breakpoints":["viewport_mobile","viewport_tablet"],"global_image_lightbox":"yes","lightbox_enable_counter":"yes","lightbox_enable_fullscreen":"yes","lightbox_enable_zoom":"yes","lightbox_enable_share":"yes","lightbox_title_src":"title","lightbox_description_src":"description"},"post":{"id":7,"title":"%D8%A3%D8%AD%D9%85%D8%AF%20%D8%A7%D9%84%D8%BA%D8%A7%D9%85%D8%AF%D9%8A%20-%20project%20floteksa","excerpt":"","featuredImage":false}};
</script>
<script src='https://project.floteksa.com/wp-content/plugins/elementor/assets/js/frontend.min.js?ver=3.7.4' id='elementor-frontend-js'></script>
<script src='https://project.floteksa.com/wp-content/plugins/elementor-pro/assets/js/elements-handlers.min.js?ver=3.7.3' id='pro-elements-handlers-js'></script>
<script src='https://project.floteksa.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/animate-circle.js?ver=2.7.0' id='animate-circle-js'></script>
<script id='elementskit-elementor-js-extra'>
var ekit_config = {"ajaxurl":"https:\/\/project.floteksa.com\/wp-admin\/admin-ajax.php","nonce":"5ba64e9a6e"};
</script>
<script src='https://project.floteksa.com/wp-content/plugins/elementskit-lite/widgets/init/assets/js/elementor.js?ver=2.7.0' id='elementskit-elementor-js'></script>
<script src='https://project.floteksa.com/wp-content/plugins/elementor/assets/lib/swiper/swiper.min.js?ver=2.7.0' id='swiper-js'></script>
<script src='https://project.floteksa.com/wp-includes/js/underscore.min.js?ver=1.13.3' id='underscore-js'></script>
<script id='wp-util-js-extra'>
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
</script>
<script src='https://project.floteksa.com/wp-includes/js/wp-util.min.js?ver=6.0.2' id='wp-util-js'></script>
<script id='wpforms-elementor-js-extra'>
var wpformsElementorVars = {"captcha_provider":"recaptcha","recaptcha_type":"v2"};
</script>
<script src='https://project.floteksa.com/wp-content/plugins/wpforms-lite/assets/js/integrations/elementor/frontend.min.js?ver=1.7.6' id='wpforms-elementor-js'></script>
			<script>
			/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
			</script>
      
      
				</body>
</html>

<!-- Page generated by LiteSpeed Cache 5.2 on 2022-09-07 17:40:10 -->